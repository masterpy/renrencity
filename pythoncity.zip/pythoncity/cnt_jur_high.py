#! D:\Program Files\python\python.exe 
# -*- coding: utf-8 -*-
#本程序用于添加县区，高中，初中数据
#
import pprint
import provinceCity as pc
import db
import sys
import time
import urllib.request
import pymysql
from bs4 import BeautifulSoup
import re
import threading

def parseCityToNumberAndName(cities):
    '''解析城市数据到编码和名称'''
    pcities = []
    for i in range(1,32):
        for city in cities['ccity_' + str(i)]:
            pcities.append(city)
    return pcities
def insertCounties(cities, mysql):
    '''下载县区数据并插入数据表'''
    starttime = time.time()
    countyUrl = 'http://support.renren.com/highschool/'
    insert = 0
    insertCountySql = 'INSERT INTO `counties` (`name`, `city_id`, `created_at`, `updated_at`)\
                      VALUES (%s, %s, now(), now())'
    queryCityIdSql = 'SELECT `id` FROM `cities` WHERE `name` LIKE %s Limit 1'
    queryCountySql = 'SELECT count(`id`) AS num FROM `counties` WHERE `name`=%s AND `city_id`=%s'
    mysql  = pymysql.connect(host = 'localhost',
                                user = 'root',
                                password = 'root',
                                db = 'pythoncity',
                                charset = 'utf8',
                                cursorclass = pymysql.cursors.DictCursor)
    mysqlcursor = mysql.cursor()
    try:
        for city in cities:
            parse = city.split(':')
            api = countyUrl + str(parse[0]) + '.html'
            try:
                htmlHandle = urllib.request.urlopen(api)
            except Exception as e:
                pprint.pprint(e)
            else:
                print('downloading %s county data successfully!' % (parse[1],))
                countyData = htmlHandle.read().decode('utf-8')
                htmlHandle.close()
                soup = BeautifulSoup(countyData, 'html.parser')
                counties = soup.find_all('a', href="#highschool_anchor")
                mysqlcursor.execute(queryCityIdSql, (parse[1]))
                cityId = mysqlcursor.fetchone()['id']
                for county in counties:
                    mysqlcursor.execute(queryCountySql, (county.string, cityId))
                    if mysqlcursor.fetchone()['num'] == 0:
                        insert += 1
                        print('插入%s-->%s' % (parse[1], county.string.strip()))
                        mysqlcursor.execute(insertCountySql, (county.string.strip(), cityId))
                mysql.commit()
    except Exception as e:
        pprint.pprint(e)
    #统计所有县级数据
    countAllCounties = 'SELECT count(`id`) as allnum FROM `counties`'
    mysqlcursor.execute(countAllCounties)
    countCounty = mysqlcursor.fetchone()['allnum']
    endtime = time.time()
    #输出提示信息
    print('-' * 70)
    sys.stdout.write(' ' * 10)
    sys.stdout.write('新增县区%d，县区总计%d，耗时%.4fs'% (insert, countCounty, endtime - starttime)),
    print(' ' * 10)
    print('-' * 70)
    return [insert, countCounty, endtime - starttime]

def insertHighSchool(cities, mysql, multiThread = False):
    '''下载高中数据并插入数据表'''
    starttime = time.time()
    highschoolurl = 'http://support.renren.com/highschool/'
    insert = 0
    insertHighSql = 'INSERT INTO `highschools` (`name`, `county_id`, `created_at`, `updated_at`)\
                    VALUES (%s, %s, now(), now())'
    queryCityIdSql = 'SELECT `id` FROM `cities` WHERE `name` LIKE %s Limit 1'
    queryCountyIdSql = 'SELECT `id` FROM `counties` WHERE `name`=%s AND `city_id`=%s Limit 1'
    counthighSql = 'SELECT count(`id`) AS num FROM `highschools` WHERE `name`=%s'
    if multiThread:
        mysql  = pymysql.connect(host = 'localhost',
                                user = 'root',
                                password = 'root',
                                db = 'pythoncity',
                                charset = 'utf8',
                                cursorclass = pymysql.cursors.DictCursor)
    mysqlcursor = mysql.cursor()
    exceptionLogs = open('cnt_jur_high.log', 'w')
    try:
        for city in cities:
            parse = city.split(':')
            api = highschoolurl + str(parse[0]) + '.html'
            try:
                html = urllib.request.urlopen(api)
            except Exception as e:
                exceptionLogs.write(str(e) + '\n')
            else:
                htmldata = html.read().decode('utf-8')
                html.close()
                print('downloading %s highschools data successfully!' % (parse[1],))
                soup = BeautifulSoup(htmldata, 'html.parser')
                #找到县级数据包括县级和学校之间关联的id
                countieshtml = soup.find_all('a', href="#highschool_anchor")
                countyData = []
                for countyhtml in countieshtml:
                    countyData.append([countyhtml.string.strip(),
                        re.search(r'[0-9]{4,}', countyhtml['onclick']).group()])
                #找到县区对应的高中
                mysqlcursor.execute(queryCityIdSql, (parse[1],))
                cityId = mysqlcursor.fetchone()['id']
                for county in countyData:
                    mysqlcursor.execute(queryCountyIdSql, (county[0], cityId))
                    try:
                        countyId = mysqlcursor.fetchone()['id']
                    except Exception as e:
                        exceptionLogs.write(u'没有找到%s的id\n' % (county[0],))
                    else:
                        highshtml = soup.select('ul[id$=' + county[1] +']')
                        if len(highshtml):
                            highshtml = highshtml[0].find_all('a')
                        else:
                            highshtml = []
                        for high in highshtml:
                            mysqlcursor.execute(counthighSql, (high.string.strip(),))
                            if mysqlcursor.fetchone()['num'] == 0:
                                insert += 1
                                print('插入%s=>%s' % (county[0], high.string.strip()))
                                mysqlcursor.execute(insertHighSql, (high.string.strip(), str(countyId)))
                        mysql.commit()
    except Exception as e:
        exceptionLogs.write(str(e) + '\n')
    finally:
        exceptionLogs.close()
    endtime = time.time()
    #统计所有数据
    countAllHighSql = 'SELECT count(`id`) as allnum FROM `highschools`'
    mysqlcursor.execute(countAllHighSql)
    allnum = mysqlcursor.fetchone()['allnum']
    #输出信息
    print('-' * 70)
    sys.stdout.write(' ' * 10)
    sys.stdout.write('新增高中%d，高中总计%d，耗时%.4fs'% (insert, allnum, endtime - starttime)),
    print(' ' * 10)
    print('-' * 70)
    return [insert, allnum, endtime - starttime]

def insertJuniorSchool(cities, mysql,  multiThread = False):
    '''下载初中数据并插入'''
    starttime = time.time()
    insert = 0
    queryCityIdSql = 'SELECT `id` FROM `cities` WHERE `name` LIKE %s Limit 1'
    queryCountyIdSql = 'SELECT `id` FROM `counties` WHERE `name`=%s AND `city_id`=%s Limit 1'
    juniorUrl = 'http://support.renren.com/juniorschool/'
    insertJuniorSql = 'INSERT INTO `juniorschools` (`name`, `county_id`, `created_at`, `updated_at`)\
                      VALUES (%s, %s, now(), now())'
    countJuniorSchool = 'SELECT count(`id`) AS num FROM `juniorschools` WHERE `name`=%s'
    if multiThread:
        mysql  = pymysql.connect(host = 'localhost',
                                user = 'root',
                                password = 'root',
                                db = 'pythoncity',
                                charset = 'utf8',
                                cursorclass = pymysql.cursors.DictCursor)
    mysqlcursor = mysql.cursor()
    exceptionLogs = open('cnt_jur_high.log', 'a')
    try:
        for city in cities:
            parse = city.split(':')
            api = juniorUrl + str(parse[0]) + '.html'
            try:
                html = urllib.request.urlopen(api)
            except Exception as e:
                exceptionLogs.write(u'下载数据时异常' + str(e) + '\n')
            else:
                htmldata = html.read().decode('utf-8')
                html.close()
                print('downloading %s juniorschools data successfully!' % (parse[1],))
                soup = BeautifulSoup(htmldata, 'html.parser')
                #找到县级数据包括县级和学校之间关联的id
                countieshtml = soup.find_all('a', href="#highschool_anchor")
                countyData = []
                for countyhtml in countieshtml:
                    countyData.append([countyhtml.string.strip(),
                        re.search(r'[0-9]{4,}', countyhtml['onclick']).group()])
                #找到初中并插入
                mysqlcursor.execute(queryCityIdSql, (parse[1],))
                cityId = mysqlcursor.fetchone()['id']
                for county in countyData:
                    mysqlcursor.execute(queryCountyIdSql, (county[0], cityId))
                    try:
                        countyId = mysqlcursor.fetchone()['id']
                    except Exception as e:
                        exceptionLogs.write(u'没有找到%s的id\n' % (county[0],));
                    else:
                        juniorshtml = soup.select('ul[id$=' + county[1] +']')
                        if len(juniorshtml):
                            juniorshtml = juniorshtml[0].find_all('a')
                        else:
                            juniorshtml = []
                        for junior in juniorshtml:
                            mysqlcursor.execute(countJuniorSchool, (junior.string.strip()))
                            if mysqlcursor.fetchone()['num'] == 0:
                                insert += 1
                                print('插入%s-->%s' % (county[0], junior.string.strip()))
                                mysqlcursor.execute(insertJuniorSql, (junior.string.strip(), countyId))
                        mysql.commit()
    except Exception as e:
        exceptionLogs.write(str(e));
    finally:
        exceptionLogs.close()
    #统计所有数据
    countAllJuniorSql = 'SELECT count(`id`) as allnum FROM `juniorschools`'
    mysqlcursor.execute(countAllJuniorSql)
    allnum = mysqlcursor.fetchone()['allnum']
    endtime = time.time()
    #打印提示信息
    print('-' * 70)
    sys.stdout.write(' ' * 10)
    sys.stdout.write('新增初中%d，初中总计%d，耗时%.4fs'% (insert, allnum, endtime - starttime))
    print(' ' * 10)
    print('-' * 70)
    return [insert, allnum, endtime - starttime]

def insertTechnicalSchool(cities, mysql, multiThread = False):
    '''插入全国技术学校'''
    starttime = time.time()
    insert = 0
    requestUrl = 'http://support.renren.com/collegeschool/'
    queryCityIdSql = 'SELECT `id` FROM `cities` WHERE `name` LIKE %s Limit 1'
    queryCountyIdSql = 'SELECT `id` FROM `counties` WHERE `name`=%s AND `city_id`=%s Limit 1'
    insertSchoolSql = 'INSERT INTO `technicalschools` (`name`, `county_id`, `created_at`, `updated_at`)\
                       VALUES (%s, %s, now(), now())'
    countSchoolSql = 'SELECT count(`id`) AS num FROM `technicalschools` WHERE `name`=%s'
    if multiThread:
        mysql  = pymysql.connect(host = 'localhost',
                                user = 'root',
                                password = 'root',
                                db = 'pythoncity',
                                charset = 'utf8',
                                cursorclass = pymysql.cursors.DictCursor)
    mysqlcursor = mysql.cursor()
    exceptionLogs = open('cnt_jur_high.log', 'a')
    try:
        for city in cities:
            parse = city.split(':')
            api = requestUrl + str(parse[0]) + '.html'
            try:
                html = urllib.request.urlopen(api)
            except Exception as e:
                exceptionLogs.write(time.asctime() + u'请求文档错误' + str(e) + '\n')
            else:
                print('----下载%s学校数据成功-----' % (parse[1],))
                htmldata = html.read().decode('utf-8')
                html.close()
                soup = BeautifulSoup(htmldata, 'html.parser')
                 #找到县级数据包括县级和学校之间关联的id
                countieshtml = soup.find_all('a', href="#highschool_anchor")
                countyData = []
                for countyhtml in countieshtml:
                    countyData.append([countyhtml.string.strip(),
                        re.search(r'[0-9]{4,}', countyhtml['onclick']).group()])
                #找到县的学校并插入数据库
                mysqlcursor.execute(queryCityIdSql, (parse[1],))
                cityId = mysqlcursor.fetchone()['id']
                for county in countyData:
                    mysqlcursor.execute(queryCountyIdSql, (county[0], cityId))
                    try:
                        countyId = mysqlcursor.fetchone()['id']
                    except Exception as e:
                        exceptionLogs.write(time.asctime() + u'没有找到%s的id\n' % (county[0],));
                    else:
                        schools = soup.select('ul[id$=' + county[1] +']')
                        if len(schools):
                            schools = schools[0].find_all('a')
                        else:
                            schools = []
                        for school in schools:
                            try:
                                schoolname = school.string.strip()
                            except Exception as e:
                                exceptionLogs.write(time.strftime('%Y-%m-%d %H:%M:%S') + u' 学校名称空值')
                            else:
                                mysqlcursor.execute(countSchoolSql, (schoolname,))
                                if mysqlcursor.fetchone()['num'] == 0:
                                    insert += 1
                                    print('插入%s-->%s' % (county[0], schoolname))
                                    mysqlcursor.execute(insertSchoolSql, (schoolname, countyId))
                        mysql.commit()
    except Exception as e:
        exceptionLogs.write(str(e))
    finally:
        exceptionLogs.close()
    ##统计现在所有技校
    countAllschoolSql = 'SELECT count(`id`) AS allnum FROM `technicalschools`'
    mysqlcursor.execute(countAllschoolSql)
    allnum = mysqlcursor.fetchone()['allnum']
    endtime = time.time()
    ##打印信息
    print('-' * 70)
    sys.stdout.write(' ' * 10)
    sys.stdout.write('新增技校%d，技校总计%d，耗时%.4fs'% (insert, allnum, endtime - starttime))
    print(' ' * 10)
    print('-' * 70)
    return [insert, allnum, endtime - starttime]

if __name__ == '__main__':
    cities = parseCityToNumberAndName(pc.allcities)
    # insertCounties(cities, db.mysql)
    # insertHighSchool(cities, db.mysql)
    # insertJuniorSchool(cities, db.mysql)
    # insertTechnicalSchool(cities, db.mysql)
    # multi threads execute
    starttime = time.time()
    ithreads = []
    ithreads.append(threading.Thread(target = insertHighSchool, args=(cities, db.mysql, True)))
    ithreads.append(threading.Thread(target = insertJuniorSchool, args=(cities, db.mysql, True)))
    ithreads.append(threading.Thread(target = insertTechnicalSchool, args=(cities, db.mysql, True)))
    for i in range(len(ithreads)):
        ithreads[i].start()
    for i in range(len(ithreads)):
        ithreads[i].join()
    endtime = time.time()
    print('need time %.4f' % (endtime - starttime,))
    db.mysql.close()
    input('输入something以结束脚本')
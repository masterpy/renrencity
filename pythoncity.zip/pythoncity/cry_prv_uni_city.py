#! D:\Program Files\python\python.exe 
# -*- coding: utf-8 -*-
#本程序用于添加国家，省，城市，大学

import pprint
import provinceCity as pc
import db
import sys
import time
import urllib.request
import pymysql


def insertCountries(countries, mysql):
	'''插入国家数据到数据表'''
	start = time.time()
	insertCountrySql = 'INSERT INTO `countries` (`name`, `updated_at`, `created_at`)\
					    VALUES (%s, now(), now())'
	countCountryNum = 'SELECT COUNT(`id`) AS num FROM `countries` WHERE `name` = %s'
	
	insert = 0
	msyqlcursor = mysql.cursor()
	for country in countries:
		msyqlcursor.execute(countCountryNum, (country,))
		if msyqlcursor.fetchone()['num'] == 0:
			insert += 1
			print('插入国家 %s ' % (country,))
			msyqlcursor.execute(insertCountrySql, (country,))
		mysql.commit()

	countAllCountriesSql = 'SELECT COUNT(`id`) AS allnum FROM `countries`'
	msyqlcursor.execute(countAllCountriesSql)
	allCount = msyqlcursor.fetchone()['allnum']

	end = time.time()
	print('-' * 70)
	sys.stdout.write(' ' * 10)
	sys.stdout.write('新增国家%d，国家总计%d，耗时%.4fs'% (insert, allCount, end - start)),
	print(' ' * 10)
	print('-' * 70)

	return [insert, allCount, end - start]

def insertProvinces(provinces, mysql):
	''' 插入国家的省份数据，在这里只插入中国的省份数据
		包括港澳台
	'''
	start = time.time()
	msyqlcursor = mysql.cursor()
	insert = 0
	#插入省份数据
	insertProvincesSql = 'INSERT INTO `provinces` (`name`, `country_id`, `created_at`, `updated_at`)\
						 VALUES (%s,%s, now(), now())'
	countProvinceSql = 'SELECT COUNT(`id`) AS num FROM `provinces` WHERE `name`=%s AND `country_id`=%s'
	queryCountryIdSql = 'SELECT `id` FROM `countries` WHERE `name`=%s'
	for country,provinces in provinces.items():
		msyqlcursor.execute(queryCountryIdSql, (country,))
		countryId = msyqlcursor.fetchone()['id']
		for province in provinces:
			msyqlcursor.execute(countProvinceSql, (province, countryId))
			if msyqlcursor.fetchone()['num'] == 0:
				print('插入--%s->%s' % (country, province))
				insert += 1
				msyqlcursor.execute(insertProvincesSql, (province, countryId))
		mysql.commit()

	#统计省份数据
	countAllProvincesSql = 'SELECT COUNT(`id`) AS allnum FROM `provinces`'
	msyqlcursor.execute(countAllProvincesSql)
	allCount = msyqlcursor.fetchone()['allnum']

	end = time.time()
	#输出信息
	print('-' * 70)
	sys.stdout.write(' ' * 10)
	sys.stdout.write('新增省份%d，省份总计%d，耗时%.4fs'% (insert, allCount, end - start)),
	print(' ' * 10)
	print('-' * 70)

	return [insert, allCount, end - start]

def insertCities(cities, mysql):
	'''插入二级城市（市）的数据'''
	starttime = time.time()
	msyqlcursor = mysql.cursor()
	insert = 0
	insertCitySql = 'INSERT INTO `cities` (`name`, `province_id`, `created_at`, `updated_at`) \
	                 VALUES (%s, %s, now(), now())'
	countCitySql = 'SELECT COUNT(`id`) AS citycount FROM `cities` WHERE `name`=%s AND `province_id`=%s'
	queryProvinceIdSql = 'SELECT `id` FROM `provinces` WHERE `name`=%s'
	for province,cities in cities.items():
		msyqlcursor.execute(queryProvinceIdSql, (province,))
		provinceId = msyqlcursor.fetchone()['id']
		for city in cities:
			msyqlcursor.execute(countCitySql, (city, provinceId))
			if msyqlcursor.fetchone()['citycount'] == 0:
				insert += 1
				print('插入%s-->城市-->%s' % (province, city))
				msyqlcursor.execute(insertCitySql, (city, provinceId))
		mysql.commit()

	#统计城市数据
	countAllCities = 'SELECT COUNT(`id`) AS allnum FROM `cities`'
	msyqlcursor.execute(countAllCities)
	allCount = msyqlcursor.fetchone()['allnum']

	endtime = time.time()
	#输出信息
	print('-' * 70)
	sys.stdout.write(' ' * 10)
	sys.stdout.write('新增城市%d，城市总计%d，耗时%.4fs'% (insert, allCount, endtime - starttime)),
	print(' ' * 10)
	print('-' * 70)

	return [insert, allCount, endtime - starttime]

def downloadUniversities():
	'''从人人网下载大学的数据，其实没什么用'''
	uniUrl = 'http://s.xnimg.cn/a83210/allunivlist.js'
	urllib.request.urlretrieve(uniUrl, './uni.js')

def moveUniversities(mysql):
	'''由于本人的另一个数据库里面存放了大学的信息，我在这里将他们copy一下'''
	starttime = time.time()
	an_db = pymysql.connect(host = 'localhost',
							user = 'root',
							password = 'root',
							db = 'city',
							charset = 'utf8',
							cursorclass = pymysql.cursors.DictCursor)
	queryUniSql = 'SELECT `u`.`name` AS `uname`, `p`.`name` AS `pname` \
	              FROM `universities` AS `u`\
	              INNER JOIN `provinces` AS `p`\
	              WHERE `u`.`province_id` = `p`.`id`'
	an_dbCursor = an_db.cursor()
	an_dbCursor.execute(queryUniSql)
	unies = an_dbCursor.fetchall()
	an_db.close() 
	##复制到本地数据库
	msyqlcursor = mysql.cursor()
	insertUniversitySql = 'INSERT INTO `universities` (`name`, `province_id`, `created_at`, `updated_at`)\
	                      VALUES(%s, %s, now(), now())'
	queryUniverSql = 'SELECT COUNT(`id`) AS unicount FROM `universities` WHERE `name`=%s AND `province_id`=%s'
	
	#定义查询省份id的函数
	def queryProvince(province):
		queryProvinceIdSql = 'SELECT `id` FROM `provinces` WHERE `name`=%s'
		msyqlcursor.execute(queryProvinceIdSql, (province,))
		return msyqlcursor.fetchone()['id']
	originProvince = unies[0]['pname']
	originProvinceId = queryProvince(originProvince)
	insert = 0
	for uni in unies:
		if uni['pname'] != originProvince:
			originProvince = uni['pname']
			originProvinceId = queryProvince(originProvince)
		msyqlcursor.execute(queryUniverSql, (uni['uname'], originProvinceId))
		if msyqlcursor.fetchone()['unicount'] == 0:
			insert += 1
			sys.stdout.write('插入%s-->大学-->%s--\n' % (uni['pname'], uni['uname'].strip()))
			msyqlcursor.execute(insertUniversitySql, (uni['uname'], originProvinceId))	
	mysql.commit()

	endtime = time.time()
	#统计信息
	queryallUni = 'SELECT COUNT(`id`) AS alluniver FROM `universities`'
	msyqlcursor.execute(queryallUni)
	allUniCount =  msyqlcursor.fetchone()['alluniver']
	#输出信息
	print('-' * 70)
	sys.stdout.write(' ' * 10)
	sys.stdout.write('新增大学%d，大学总计%d，耗时%.4fs' % (insert, allUniCount, endtime - starttime)),
	print(' ' * 10)
	print('-' * 70)

if __name__ == '__main__':
	countries = pc.parseCountries(pc.countries)
	provinces = pc.parseProvinces(pc.provinceMap)
	cities = pc.parseCities(pc.provinceMap, pc.allcities)

	#执行插入操作
	starttime = time.time()
	
	insertCountries(countries, db.mysql)
	insertProvinces(provinces, db.mysql)
	insertCities(cities, db.mysql)
	#moveUniversities(db.mysql)


	#输出耗时信息
	endtime = time.time()
	sys.stdout.write(' ' * 10)
	print('耗时%.4f' % ( endtime - starttime,))

	#关闭mysql连接
	db.mysql.close()

	input('输入任何字符以结束脚本')

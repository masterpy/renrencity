#! D:\Program Files\python\python.exe 
# -*- coding: utf-8 -*-

import pymysql

mysql  = pymysql.connect(host = 'localhost',
								user = 'root',
								password = 'root',
								db = 'pythoncity',
								charset = 'utf8',
								cursorclass = pymysql.cursors.DictCursor)


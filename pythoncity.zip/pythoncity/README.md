### Python 爬人人网学校数据
![爬虫](http://g.hiphotos.baidu.com/baike/w%3D268/sign=1fe22e5355fbb2fb342b5f14774a2043/5ab5c9ea15ce36d39335a53e3af33a87e950b18e.jpg)
---------------------------------------------------------------------

使用方法：

1.    `git clone`
2.    配置数据库`db.py`
3.    安装依赖，`pymysql, bs4`
4.    `python -u cry_prv_uni_city.py`
5.    `python -u cnt_jur_high.py`

